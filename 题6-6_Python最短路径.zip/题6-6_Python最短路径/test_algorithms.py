"""运行：python -m unittest -v test_algorithms.py

除81组原图城市对外，使用固定种子的随机图作算法测试（不是教材数据）。
NetworkX仅作为测试中的独立参考实现。
"""
import math
import random
import tempfile
import unittest
from pathlib import Path

import networkx as nx

from algorithms import GraphData, RoutingSolver, load_graph, path_cost

HERE = Path(__file__).resolve().parent
EXPECTED_DISTANCE = [
    [0, 2, 3.5, 1.5, 4, 5, 3.5, 4, 5],
    [2, 0, 1.5, 3, 2, 3, 4.5, 3, 3],
    [3.5, 1.5, 0, 4.5, 3.5, 4.5, 6, 4.5, 4.5],
    [1.5, 3, 4.5, 0, 3, 4, 2, 2.5, 4],
    [4, 2, 3.5, 3, 0, 1, 2.5, 1, 1],
    [5, 3, 4.5, 4, 1, 0, 3.5, 2, 1],
    [3.5, 4.5, 6, 2, 2.5, 3.5, 0, 1.5, 3.5],
    [4, 3, 4.5, 2.5, 1, 2, 1.5, 0, 2],
    [5, 3, 4.5, 4, 1, 1, 3.5, 2, 0],
]


class ShortestPathTests(unittest.TestCase):
    def setUp(self):
        self.graph = load_graph(HERE / "graph_data.json")

    def check_oracle(self, graph):
        solver = RoutingSolver(graph)
        g = nx.DiGraph() if graph.directed else nx.Graph()
        g.add_nodes_from(graph.cities)
        g.add_weighted_edges_from(graph.edges)
        for i, source in enumerate(graph.cities):
            expected = nx.single_source_dijkstra_path_length(g, source, weight="weight")
            for j, target in enumerate(graph.cities):
                value = expected.get(target, math.inf)
                self.assertTrue(math.isclose(solver.dd[i][j], value, abs_tol=1e-10))
                self.assertTrue(math.isclose(solver.df[i][j], value, abs_tol=1e-10))
                for method in ("Dijkstra", "Floyd"):
                    distance, route = solver.route(source, target, method)
                    if math.isinf(distance):
                        self.assertEqual(route, [])
                    else:
                        self.assertEqual(route[0], source)
                        self.assertEqual(route[-1], target)
                        self.assertEqual(len(route), len(set(route)))
                        self.assertTrue(math.isclose(path_cost(graph, route), value, abs_tol=1e-10))
        return solver

    def test_original_graph_and_all_81_city_pairs(self):
        self.assertEqual(len(self.graph.cities), 9)
        self.assertEqual(len(self.graph.edges), 16)
        solver = self.check_oracle(self.graph)
        self.assertEqual(solver.df, EXPECTED_DISTANCE)

    def test_one_city_and_self_query(self):
        solver = self.check_oracle(GraphData(["A"], []))
        self.assertEqual(solver.route("A", "A"), (0, ["A"]))

    def test_disconnected_graph(self):
        solver = self.check_oracle(GraphData(["A", "B", "C"], [("A", "B", 2)]))
        self.assertEqual(solver.route("A", "C"), (math.inf, []))

    def test_directed_graph_and_unreachable_reverse(self):
        graph = GraphData(["A", "B", "C"], [("A", "B", 2), ("B", "C", 3)], directed=True)
        solver = self.check_oracle(graph)
        self.assertEqual(solver.route("A", "C", "Floyd"), (5, ["A", "B", "C"]))
        self.assertEqual(solver.route("C", "A"), (math.inf, []))

    def test_zero_weight_edges_and_cycles(self):
        graph = GraphData(["A", "B", "C", "D"],
                          [("A", "B", 0), ("B", "C", 0), ("A", "C", 0), ("C", "D", 1)])
        self.check_oracle(graph)

    def test_equal_shortest_routes_need_not_match(self):
        graph = GraphData(["A", "B", "C", "D"],
                          [("A", "B", 1), ("A", "C", 1), ("B", "D", 1), ("C", "D", 1)])
        solver = self.check_oracle(graph)
        self.assertEqual(solver.route("A", "D")[0], 2)

    def test_change_add_delete_without_mutating_original(self):
        solver = RoutingSolver(self.graph)
        self.assertEqual(solver.route("南京", "杭州")[0], 1)
        changed = self.graph.changed_edge("南京", "杭州", 4)
        self.assertEqual(self.check_oracle(changed).route("南京", "杭州")[0], 2)
        removed = changed.changed_edge("南京", "杭州", None)
        self.assertNotIn("杭州", removed.adjacency()["南京"])
        self.check_oracle(removed)
        added = removed.changed_edge("石家庄", "杭州", .5)
        self.assertEqual(self.check_oracle(added).route("石家庄", "杭州")[0], .5)
        self.assertEqual(self.graph.adjacency()["南京"]["杭州"], 1)

    def test_invalid_weights_cities_self_loops_duplicates(self):
        for weight in [-1, math.inf, math.nan, True, "2"]:
            with self.assertRaises(ValueError):
                GraphData(["A", "B"], [("A", "B", weight)])
        for cities, edges in [(["A", "A"], []), (["A"], [("A", "B", 1)]),
                              (["A"], [("A", "A", 1)]),
                              (["A", "B"], [("A", "B", 1), ("B", "A", 2)])]:
            with self.assertRaises(ValueError):
                GraphData(cities, edges)
        with self.assertRaises(ValueError):
            RoutingSolver(self.graph).route("不存在", "南京")
        with self.assertRaises(ValueError):
            self.graph.changed_edge("石家庄", "杭州", None)

    def test_export_and_json_reload(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths = RoutingSolver(self.graph).export(temporary)
            self.assertEqual(len(paths), 6)
            self.assertTrue(all(p.exists() and p.stat().st_size > 0 for p in paths))
            reloaded = load_graph(Path(temporary) / "当前网络.json")
            self.assertEqual(RoutingSolver(reloaded).df, RoutingSolver(self.graph).df)

    def test_random_nonnegative_graphs_with_fixed_seed(self):
        rng = random.Random(640)
        for directed in [False, True]:
            for _ in range(40):
                cities = [f"V{i}" for i in range(rng.randint(2, 9))]
                edges = []
                for i, u in enumerate(cities):
                    for j, v in enumerate(cities):
                        if i == j or (not directed and j < i):
                            continue
                        if rng.random() < .30:
                            edges.append((u, v, rng.choice([0, .1, .25, .5, 1, 1.5, 3, 8])))
                self.check_oracle(GraphData(cities, edges, directed=directed))


if __name__ == "__main__":
    unittest.main(verbosity=2)
