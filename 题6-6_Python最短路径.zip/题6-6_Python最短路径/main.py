"""题6-6可视化主程序（NetworkX + Matplotlib）。

直接运行：python main.py
无图形环境：python main.py --headless
导出动画：python main.py --headless --gif
自定义查询：python main.py --source 青岛 --target 武汉 --algorithm Floyd
修改权值：python main.py --set-edge 南京 杭州 4

算法见algorithms.py；本文件中NetworkX仅负责绘图和独立校验。
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import sys

import matplotlib

# 在导入pyplot前选择后端；自动支持无显示器的服务器。
HEADLESS = "--headless" in sys.argv or (
    sys.platform.startswith("linux") and not os.environ.get("DISPLAY"))
if HEADLESS:
    matplotlib.use("Agg")
elif sys.platform.startswith("linux") and matplotlib.get_backend().lower() == "agg":
    try:
        import tkinter  # noqa: F401
        matplotlib.use("TkAgg")
    except ImportError:
        pass

import matplotlib.pyplot as plt
from matplotlib import font_manager, patheffects
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.lines import Line2D
from matplotlib.widgets import Button, RadioButtons, TextBox
import networkx as nx

from algorithms import GraphData, RoutingSolver, format_number, load_graph

HERE = Path(__file__).resolve().parent
COLORS = {
    "bg": "#091222", "panel": "#101e33", "grid": "#233955",
    "text": "#e7eefc", "muted": "#8fa5c6", "edge": "#57708e",
    "start": "#31e5bd", "end": "#ff668e", "path": "#ffcf4b",
    "accent": "#63b9ff", "node": "#163c63", "white": "#ffffff",
}


def configure_fonts():
    """按当前系统选择中文字体；Windows/macOS/Linux均有候选。"""
    candidates = ["Microsoft YaHei", "PingFang SC", "Noto Sans CJK SC",
                  "Source Han Sans SC", "SimHei", "WenQuanYi Micro Hei",
                  "Noto Sans CJK JP", "Arial Unicode MS"]
    available = {f.name for f in font_manager.fontManager.ttflist}
    chosen = next((name for name in candidates if name in available), None)
    plt.style.use("default")
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [chosen or "DejaVu Sans", "DejaVu Sans"],
        "axes.unicode_minus": False, "figure.facecolor": COLORS["bg"],
        "axes.facecolor": COLORS["bg"], "text.color": COLORS["text"],
        "savefig.facecolor": COLORS["bg"], "font.size": 11,
    })
    if not chosen:
        print("提示：系统未发现中文字体。请安装Noto Sans CJK SC或微软雅黑后重启。")
    return chosen or "DejaVu Sans"


def as_networkx(graph: GraphData):
    g = nx.DiGraph() if graph.directed else nx.Graph()
    g.add_nodes_from(graph.cities)
    g.add_weighted_edges_from(graph.edges)
    return g


def networkx_check(solver: RoutingSolver):
    """独立校验，不参与主算法求解。"""
    g = as_networkx(solver.graph)
    n = 0
    for i, source in enumerate(solver.graph.cities):
        oracle = nx.single_source_dijkstra_path_length(g, source, weight="weight")
        for j, target in enumerate(solver.graph.cities):
            if not math.isclose(solver.dd[i][j], oracle.get(target, math.inf),
                                rel_tol=1e-10, abs_tol=1e-10):
                raise AssertionError(f"NetworkX校验失败：{source}—{target}")
            n += 1
    return n


class RoutingApp:
    def __init__(self, graph, source, target, method="Dijkstra", output_dir=None,
                 interactive=True):
        self.font = configure_fonts()
        self.graph = graph
        self.solver = RoutingSolver(graph)
        self.checked = networkx_check(self.solver)
        self.source, self.target, self.method = source, target, method
        self.output = Path(output_dir or HERE / "results")
        self.output.mkdir(parents=True, exist_ok=True)
        self.interactive = interactive
        self.widgets = []  # 保留引用，否则控件可能被回收。
        self.phase = 0.0
        self.running = True
        self.click_source_next = True
        self.animation = None
        self.fig = plt.figure(figsize=(15.8, 9.5), dpi=110)
        if hasattr(self.fig.canvas.manager, "set_window_title"):
            self.fig.canvas.manager.set_window_title("题6-6 | 城市最短时间与路由实验室")
        self.ax = self.fig.add_axes([.045, .235, .595, .54])
        self.info = self.fig.add_axes([.685, .235, .285, .50])
        self.info.set_facecolor(COLORS["panel"])
        self.fig.text(.045, .94, "城市最短时间与路由实验室", fontsize=26, weight="bold")
        self.fig.text(.045, .898, "通信网理论与技术基础  /  习题 6-6  /  图 6-40",
                      fontsize=12, color=COLORS["muted"])
        self.fig.text(.045, .845, "01  原图拓扑复现", fontsize=14, weight="bold",
                      color=COLORS["accent"])
        self.fig.text(.045, .813, "边上数字 = 通行时间；节点位置保留教材的三行三列布局",
                      fontsize=10, color=COLORS["muted"])
        self.fig.text(.685, .845, "02  最短路径查询", fontsize=14, weight="bold",
                      color=COLORS["accent"])
        self.status_artist = self.fig.text(.045, .193, "", fontsize=10,
                                           color=COLORS["muted"])
        self.fig.text(.045, .163, "点击节点交替设置起点 / 终点，也可在下方输入完整城市名。",
                      fontsize=9, color=COLORS["muted"])
        self.build_network()
        self.refresh_route()
        if interactive:
            self.build_controls()
            self.fig.canvas.mpl_connect("button_press_event", self.on_click)
        else:
            self.fig.text(.045, .12, "Dijkstra：最小堆 + 前驱回溯     |     Floyd：三层循环 + 下一跳路由",
                          fontsize=12, color=COLORS["text"])
            self.fig.text(.045, .067, "两种算法独立实现；全部城市对通过一致性及 NetworkX 校验。",
                          fontsize=10, color=COLORS["muted"])
        self.animation = FuncAnimation(self.fig, self.tick, interval=60, blit=False,
                                       cache_frame_data=False)
        self.fig.canvas.draw()

    def build_network(self):
        self.g = as_networkx(self.graph)
        if all(city in self.graph.positions for city in self.graph.cities):
            self.pos = {city: tuple(self.graph.positions[city]) for city in self.graph.cities}
        else:
            # 未提供坐标的自定义图使用可重复的力导向布局。
            self.pos = nx.spring_layout(self.g, seed=66, weight=None)
        self.ax.clear()
        self.ax.set_facecolor(COLORS["bg"])
        self.ax.axis("off")
        arrow_options = {"arrowsize": 20} if self.graph.directed else {}
        nx.draw_networkx_edges(self.g, self.pos, ax=self.ax, width=2.0,
                               edge_color=COLORS["edge"], alpha=.65,
                               arrows=self.graph.directed,
                               node_size=2400, **arrow_options)
        nx.draw_networkx_nodes(self.g, self.pos, ax=self.ax, node_size=3000,
                               node_color=COLORS["accent"], alpha=.065)
        self.nodes = nx.draw_networkx_nodes(
            self.g, self.pos, ax=self.ax, node_size=2150,
            node_color=COLORS["node"], edgecolors=COLORS["accent"], linewidths=1.9)
        self.nodes.set_zorder(5)
        labels = nx.draw_networkx_labels(self.g, self.pos, ax=self.ax, font_family=self.font,
                                         font_size=14, font_weight="bold", font_color=COLORS["white"])
        for label in labels.values():
            label.set_zorder(6)
        # 手动定位边权，避免原图中水平边/对角边的标签互相遮挡。
        self.weight_labels = {}
        for u, v, w in self.graph.edges:
            x1, y1 = self.pos[u]
            x2, y2 = self.pos[v]
            x, y = (x1 + x2) / 2, (y1 + y2) / 2
            if abs(y1 - y2) < 1e-8:
                y += .075
            elif abs(x1 - x2) < 1e-8:
                x += .095
            else:
                x += .06
                y += .06
            label = self.ax.text(
                x, y, format_number(w), ha="center", va="center", fontsize=11,
                color=COLORS["text"], weight="bold", zorder=8,
                bbox={"boxstyle": "round,pad=.25", "fc": COLORS["bg"],
                      "ec": COLORS["grid"], "lw": .7, "alpha": .97})
            self.weight_labels[(u, v)] = label
        xs, ys = zip(*self.pos.values())
        dx, dy = max(xs) - min(xs) or 1, max(ys) - min(ys) or 1
        self.ax.set_xlim(min(xs) - dx * .18, max(xs) + dx * .18)
        self.ax.set_ylim(min(ys) - dy * .16, max(ys) + dy * .16)
        self.route_lines = []
        self.marker, = self.ax.plot([], [], "o", ms=10, color=COLORS["white"],
                                    mec=COLORS["path"], mew=2.4, zorder=4)
        self.marker.set_path_effects([patheffects.withStroke(linewidth=8,
                                                            foreground="#ffcf4b40")])
        self.ax.legend(handles=[
            Line2D([0], [0], marker="o", linestyle="", color=COLORS["start"], label="起点"),
            Line2D([0], [0], marker="o", linestyle="", color=COLORS["end"], label="终点"),
            Line2D([0], [0], color=COLORS["path"], lw=3, label="最短路径"),
        ], loc="lower center", bbox_to_anchor=(.5, -.055), ncol=3,
                       frameon=False, labelcolor=COLORS["muted"], fontsize=10)

    def refresh_route(self):
        self.distance, self.path = self.solver.route(self.source, self.target, self.method)
        for line in self.route_lines:
            line.remove()
        self.route_lines = []
        for u, v in zip(self.path, self.path[1:]):
            x1, y1 = self.pos[u]
            x2, y2 = self.pos[v]
            glow, = self.ax.plot([x1, x2], [y1, y2], color=COLORS["path"],
                                 lw=13, alpha=.10, zorder=1)
            line, = self.ax.plot([x1, x2], [y1, y2], color=COLORS["path"],
                                 lw=4.4, alpha=.95, zorder=2, solid_capstyle="round")
            self.route_lines.extend([glow, line])
        colors = [COLORS["start"] if c == self.source else
                  COLORS["end"] if c == self.target else
                  "#61511d" if c in self.path else COLORS["node"]
                  for c in self.graph.cities]
        borders = [COLORS["start"] if c == self.source else
                   COLORS["end"] if c == self.target else
                   COLORS["path"] if c in self.path else COLORS["accent"]
                   for c in self.graph.cities]
        self.nodes.set_facecolors(colors)
        self.nodes.set_edgecolors(borders)
        for (u, v), label in self.weight_labels.items():
            active = any((a == u and b == v) or (
                not self.graph.directed and a == v and b == u)
                         for a, b in zip(self.path, self.path[1:]))
            label.set_color(COLORS["path"] if active else COLORS["text"])
        self.phase = 0.0
        self.draw_info()
        self.set_status(f"{self.method}查询完成 · {len(self.graph.cities)}座城市 · "
                        f"{len(self.graph.edges)}条连接 · {self.checked}组城市对校验通过")
        self.update_visual(0.0)
        self.fig.canvas.draw_idle()

    def draw_info(self):
        self.info.clear()
        self.info.set_facecolor(COLORS["panel"])
        self.info.set_xlim(0, 1)
        self.info.set_ylim(0, 1)
        self.info.set_xticks([])
        self.info.set_yticks([])
        for spine in self.info.spines.values():
            spine.set_color(COLORS["grid"])
        self.info.text(.06, .94, f"{self.source}  →  {self.target}", fontsize=17, weight="bold")
        self.info.text(.06, .875, f"当前算法  {self.method}   /   {'有向' if self.graph.directed else '无向'}网络",
                       fontsize=10, color=COLORS["muted"])
        self.info.text(.06, .727, format_number(self.distance) if self.path else "不可达",
                       fontsize=43, color=COLORS["path"], weight="bold")
        self.info.text(.38, .745, f"最短时间 · {self.graph.unit}", fontsize=10,
                       color=COLORS["muted"])
        self.info.plot([.06, .94], [.65, .65], color=COLORS["grid"], lw=1)
        self.info.text(.06, .59, f"路由明细  /  {max(0, len(self.path)-1)} 跳", fontsize=11,
                       weight="bold")
        if not self.path:
            self.info.text(.06, .46, "当前连接关系下不存在可达路径。", fontsize=11,
                           color=COLORS["muted"])
        elif len(self.path) == 1:
            self.info.text(.06, .46, "起点与终点相同，无需经过任何连接。", fontsize=10,
                           color=COLORS["muted"])
        else:
            steps = list(zip(self.path, self.path[1:]))
            gap = min(.073, .42 / len(steps))
            adj = self.graph.adjacency()
            for i, (u, v) in enumerate(steps):
                y = .50 - i * gap
                self.info.text(.06, y, f"{i+1:02d}", fontsize=10, color=COLORS["accent"])
                self.info.text(.17, y, f"{u} → {v}", fontsize=11)
                self.info.text(.92, y, format_number(adj[u][v]), ha="right", fontsize=11,
                               color=COLORS["path"])
        self.info.text(.06, .052, "等长最短路可能不唯一；此处显示当前算法的一条。",
                       fontsize=8, color=COLORS["muted"])
        self.info.text(.06, .018, "动态光点为路径示意，不代表真实交通速度。",
                       fontsize=8, color=COLORS["muted"])

    def set_status(self, text, error=False):
        self.status_artist.set_text(text)
        self.status_artist.set_color(COLORS["end"] if error else COLORS["muted"])

    def update_visual(self, phase):
        count = max(0, len(self.path) - 1)
        for segment in range(count):
            a = 1.0 if phase >= segment else .16
            self.route_lines[segment * 2 + 1].set_alpha(a)
        if count:
            # 前2个阶段逐段点亮，末尾阶段保持完整路径；之后循环。
            position = min(phase, count)
            segment = min(int(position), count - 1)
            fraction = position - segment
            x1, y1 = self.pos[self.path[segment]]
            x2, y2 = self.pos[self.path[segment + 1]]
            self.marker.set_data([x1 + fraction * (x2 - x1)],
                                 [y1 + fraction * (y2 - y1)])
        elif self.path:
            x, y = self.pos[self.path[0]]
            self.marker.set_data([x], [y])
        else:
            self.marker.set_data([], [])

    def tick(self, _frame):
        if self.running:
            self.phase = (self.phase + .045) % (max(1, len(self.path) - 1) + 1.1)
            self.update_visual(self.phase)
        return []

    def make_button(self, rect, label, handler):
        ax = self.fig.add_axes(rect)
        button = Button(ax, label, color=COLORS["panel"], hovercolor="#264260")
        button.label.set_color(COLORS["text"])
        button.label.set_fontsize(10)
        button.on_clicked(handler)
        self.widgets.append(button)
        return button

    def make_textbox(self, rect, initial):
        ax = self.fig.add_axes(rect)
        textbox = TextBox(ax, "", initial=initial, color=COLORS["panel"],
                          hovercolor="#1b304b")
        textbox.text_disp.set_color(COLORS["text"])
        textbox.cursor.set_color(COLORS["text"])
        self.widgets.append(textbox)
        return textbox

    def build_controls(self):
        radio_ax = self.fig.add_axes([.685, .755, .285, .065], facecolor=COLORS["panel"])
        self.radio = RadioButtons(radio_ax, ("Dijkstra", "Floyd"),
                                  active=0 if self.method == "Dijkstra" else 1,
                                  activecolor=COLORS["path"])
        for label in self.radio.labels:
            label.set_color(COLORS["text"])
            label.set_fontsize(11)
        self.radio.on_clicked(self.on_method)
        self.widgets.append(self.radio)
        self.fig.text(.045, .126, "起点", fontsize=11)
        self.source_box = self.make_textbox([.095, .112, .155, .04], self.source)
        self.fig.text(.275, .126, "终点", fontsize=11)
        self.target_box = self.make_textbox([.325, .112, .155, .04], self.target)
        self.source_box.on_submit(self.query)
        self.target_box.on_submit(self.query)
        self.make_button([.505, .112, .105, .04], "查询 / 重播", self.query)
        self.pause_button = self.make_button([.625, .112, .095, .04], "暂停动画", self.pause)
        self.make_button([.735, .112, .095, .04], "交换起终点", self.swap)
        self.make_button([.845, .112, .125, .04], "导出全部结果", self.save)
        self.fig.text(.045, .053, "连接编辑", fontsize=11)
        self.edge_box = self.make_textbox([.12, .04, .43, .04], "南京 杭州 4")
        self.make_button([.565, .04, .10, .04], "应用修改", self.edit_edge)
        self.make_button([.68, .04, .13, .04], "恢复教材原图", self.reset)
        self.fig.text(.045, .011, "格式：城市1 城市2 时间；增边/改权均可。输入 城市1 城市2 删除 可删边。修改仅在内存中，导出后才保存。",
                      fontsize=8, color=COLORS["muted"])

    def query(self, _=None):
        try:
            source, target = self.source_box.text.strip(), self.target_box.text.strip()
            self.solver.route(source, target, self.method)
            self.source, self.target = source, target
            self.running = True
            self.pause_button.label.set_text("暂停动画")
            self.refresh_route()
        except (ValueError, KeyError) as e:
            self.set_status(str(e), True)
            self.fig.canvas.draw_idle()

    def on_method(self, method):
        self.method = method
        self.refresh_route()

    def pause(self, _=None):
        self.running = not self.running
        self.pause_button.label.set_text("暂停动画" if self.running else "继续动画")
        self.fig.canvas.draw_idle()

    def swap(self, _=None):
        source, target = self.source, self.target
        self.source_box.set_val(target)
        self.target_box.set_val(source)
        self.query()

    def replace_graph(self, graph):
        solver = RoutingSolver(graph)
        checked = networkx_check(solver)
        if self.animation:
            self.animation.event_source.stop()
        self.graph, self.solver, self.checked = graph, solver, checked
        self.build_network()
        self.refresh_route()
        if self.animation:
            self.animation.event_source.start()

    def edit_edge(self, _=None):
        try:
            parts = self.edge_box.text.replace(",", " ").replace("，", " ").split()
            if len(parts) != 3:
                raise ValueError("请输入：城市1 城市2 时间；或：城市1 城市2 删除。")
            u, v, raw = parts
            weight = None if raw.lower() in ("删除", "delete", "del") else float(raw)
            self.replace_graph(self.graph.changed_edge(u, v, weight))
            self.set_status(f"已{'删除' if weight is None else '更新'}连接 {u}—{v}；两种算法已重新计算全部矩阵。")
            self.fig.canvas.draw_idle()
        except (ValueError, KeyError) as e:
            self.set_status(f"修改失败：{e}", True)
            self.fig.canvas.draw_idle()

    def reset(self, _=None):
        try:
            graph = load_graph(HERE / "graph_data.json")
            source, target = "石家庄", "杭州"
            # TextBox.set_val会触发on_submit：批量更新时先抑制回调，避免重入。
            source_events, target_events = self.source_box.eventson, self.target_box.eventson
            self.source_box.eventson = self.target_box.eventson = False
            try:
                self.source_box.set_val(source)
                self.target_box.set_val(target)
            finally:
                self.source_box.eventson, self.target_box.eventson = source_events, target_events
            self.source, self.target = source, target
            self.replace_graph(graph)
        except (ValueError, OSError) as e:
            self.set_status(f"恢复失败：{e}", True)

    def save(self, _=None):
        try:
            self.solver.export(self.output)
            self.save_png(self.output / "当前查询_最短路径.png")
            self.set_status(f"已导出CSV矩阵、全部路由、当前网络JSON与查询图：{self.output}")
        except OSError as e:
            self.set_status(f"导出失败：{e}", True)
        self.fig.canvas.draw_idle()

    def on_click(self, event):
        if event.inaxes != self.ax or event.xdata is None:
            return
        click = (event.x, event.y)
        nearest = None
        minimum = math.inf
        for city, pos in self.pos.items():
            pixel = self.ax.transData.transform(pos)
            distance = math.hypot(pixel[0] - click[0], pixel[1] - click[1])
            if distance < minimum:
                nearest, minimum = city, distance
        if minimum > 35:
            return
        if self.click_source_next:
            self.source_box.set_val(nearest)
        else:
            self.target_box.set_val(nearest)
        self.click_source_next = not self.click_source_next
        self.query()

    def save_png(self, path):
        current = self.phase
        self.update_visual(max(1, len(self.path) - 1))
        self.fig.savefig(path, dpi=160, facecolor=COLORS["bg"])
        self.update_visual(current)

    def save_gif(self, path):
        was_running = self.running
        self.running = False
        count = max(1, len(self.path) - 1)
        frames = 72
        def frame(i):
            self.update_visual((i / (frames - 1)) * (count + .7))
            return []
        animation = FuncAnimation(self.fig, frame, frames=frames, interval=80,
                                   blit=False, repeat=True)
        animation.save(path, writer=PillowWriter(fps=12), dpi=80)
        self.running = was_running

    def show(self):
        plt.show()


def print_summary(solver, source, target):
    cities = solver.graph.cities
    print("\n图6-40最短时间矩阵（单位：" + solver.graph.unit + "）")
    print("起点\\终点\t" + "\t".join(cities))
    for city, row in zip(cities, solver.df):
        print(city + "\t" + "\t".join(format_number(x) for x in row))
    for method in ("Dijkstra", "Floyd"):
        distance, route = solver.route(source, target, method)
        print(f"\n{method}：{source} → {target}")
        print("最短时间：" + format_number(distance) + " " + solver.graph.unit)
        print("路由：" + (" → ".join(route) or "不可达"))
    print("\n说明：最短路不一定唯一，两种算法可返回不同的等长路线。")


def parse_args():
    p = argparse.ArgumentParser(description="题6-6 | Dijkstra与Floyd最短路径可视化")
    p.add_argument("--data", type=Path, default=HERE / "graph_data.json", help="网络JSON文件")
    p.add_argument("--source", default=None, help="起点；默认石家庄或自定义图的首城市")
    p.add_argument("--target", default=None, help="终点；默认杭州或自定义图的末城市")
    p.add_argument("--algorithm", choices=["Dijkstra", "Floyd"], default="Dijkstra")
    p.add_argument("--headless", action="store_true", help="只导出文件，不打开窗口")
    p.add_argument("--gif", action="store_true", help="同时导出动态GIF")
    p.add_argument("--output", type=Path, default=HERE / "results", help="结果保存目录")
    p.add_argument("--set-edge", nargs=3, action="append", metavar=("城市1", "城市2", "时间"),
                   help="增加/修改连接；时间为delete时删除，可多次使用")
    p.add_argument("--smoke-test", action="store_true", help=argparse.SUPPRESS)
    return p.parse_args()


def smoke_test(app):
    """真实窗口中的控件回调测试；测试结束自动关闭，不留下后台服务。"""
    original = app.solver.df
    app.source_box.set_val("青岛")
    app.target_box.set_val("武汉")
    app.query()
    assert app.distance == 6.0
    app.radio.set_active(1)
    assert app.method == "Floyd" and app.distance == 6.0
    app.swap()
    assert app.source == "武汉" and app.target == "青岛" and app.distance == 6.0
    from types import SimpleNamespace
    for city in ["郑州", "上海"]:
        x, y = app.pos[city]
        px, py = app.ax.transData.transform((x, y))
        app.on_click(SimpleNamespace(inaxes=app.ax, xdata=x, ydata=y, x=px, y=py))
    assert app.source == "郑州" and app.target == "上海" and app.distance == 4.0
    app.pause()
    assert not app.running
    app.pause()
    assert app.running
    app.edge_box.set_val("南京 杭州 4")
    app.edit_edge()
    assert app.graph.adjacency()["南京"]["杭州"] == 4
    app.edge_box.set_val("南京 杭州 删除")
    app.edit_edge()
    assert "杭州" not in app.graph.adjacency()["南京"]
    app.edge_box.set_val("南京 杭州 -1")
    app.edit_edge()
    assert "修改失败" in app.status_artist.get_text()
    app.reset()
    assert app.solver.df == original
    assert app.source == "石家庄" and app.target == "杭州"
    assert app.source_box.text == "石家庄" and app.target_box.text == "杭州"
    app.source_box.set_val("不存在")
    app.query()
    assert "不存在" in app.status_artist.get_text()
    app.source_box.set_val("石家庄")
    app.target_box.set_val("杭州")
    app.edge_box.set_val("南京 杭州 4")
    app.query()
    app.save()
    print("GUI_SMOKE_TEST_OK：窗口、查询、算法切换、交换起终点、节点点击、暂停、改权、删边、错误处理、恢复和导出均通过。",
          flush=True)
    timer = app.fig.canvas.new_timer(interval=1800)
    timer.single_shot = True
    timer.add_callback(lambda: plt.close(app.fig))
    app._close_timer = timer
    timer.start()


def main():
    args = parse_args()
    graph = load_graph(args.data)
    for u, v, raw in args.set_edge or []:
        graph = graph.changed_edge(u, v, None if raw.lower() in ("delete", "del", "删除") else float(raw))
    source = args.source or ("石家庄" if "石家庄" in graph.cities else graph.cities[0])
    target = args.target or ("杭州" if "杭州" in graph.cities else graph.cities[-1])
    solver = RoutingSolver(graph)
    checked = networkx_check(solver)
    print_summary(solver, source, target)
    solver.export(args.output)
    print(f"\n校验通过：{checked}组城市对；已导出全部时间矩阵与路由。")
    graphical = matplotlib.get_backend().lower() not in ("agg", "pdf", "svg", "ps", "cairo")
    interactive = not args.headless and not HEADLESS and graphical
    app = RoutingApp(graph, source, target, args.algorithm, args.output, interactive=interactive)
    app.save_png(args.output / "最短路径预览.png")
    if args.gif:
        print("正在生成动态GIF…", flush=True)
        app.save_gif(args.output / "最短路径动画.gif")
        print("动态GIF已生成。", flush=True)
    if interactive:
        if args.smoke_test:
            smoke_test(app)
        app.show()
    else:
        if not args.headless:
            print("当前环境无交互图形后端；已保存PNG、CSV等结果。请在本地桌面运行以打开窗口。")
        plt.close(app.fig)
    print(f"结果目录：{args.output.resolve()}")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, KeyError) as error:
        print(f"输入或文件错误：{error}", file=sys.stderr)
        sys.exit(1)
