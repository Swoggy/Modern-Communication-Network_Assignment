@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
    set "PYTHON=python"
) else (
    set "PYTHON=py -3"
)
%PYTHON% -c "import networkx, matplotlib, PIL" >nul 2>nul
if errorlevel 1 (
    echo 正在安装必要的Python依赖...
    %PYTHON% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo 依赖安装失败。请确认Python已安装且网络可用。
        pause
        exit /b 1
    )
)
%PYTHON% main.py
pause
