"""题6-6算法核心：手写Dijkstra与Floyd，不调用NetworkX的最短路径函数。

边权表示时间，必须为有限非负数。无连接用math.inf表示，不能用0代替。
同长度路线可能不唯一；严格改善时才更新，以固定城市顺序获得可重复结果。
"""
from __future__ import annotations

import csv
import heapq
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class GraphData:
    cities: list[str]
    edges: list[tuple[str, str, float]]
    positions: dict[str, tuple[float, float]] = field(default_factory=dict)
    directed: bool = False
    unit: str = "时间单位"
    title: str = "城市时间网络"

    def __post_init__(self) -> None:
        if not self.cities or any(not isinstance(c, str) or not c.strip() for c in self.cities):
            raise ValueError("cities必须是非空的城市名称列表。")
        if len(set(self.cities)) != len(self.cities):
            raise ValueError("城市名称不能重复。")
        if not isinstance(self.directed, bool):
            raise ValueError("directed必须是true或false。")
        seen = set()
        normalized = []
        for entry in self.edges:
            if len(entry) != 3:
                raise ValueError("每条边必须为[城市1, 城市2, 时间]。")
            u, v, weight = entry
            if u not in self.cities or v not in self.cities:
                raise ValueError(f"连接包含未定义城市：{u}—{v}")
            if u == v:
                raise ValueError("本程序不接受自环；同一城市到自身的时间为0。")
            if isinstance(weight, bool) or not isinstance(weight, (int, float)):
                raise ValueError("连接时间必须是数值。")
            w = float(weight)
            if not math.isfinite(w) or w < 0:
                raise ValueError("连接时间必须是有限非负数，Dijkstra不能处理负权。")
            key = (u, v) if self.directed else frozenset((u, v))
            if key in seen:
                raise ValueError(f"重复连接：{u}—{v}。请保留一个权值。")
            seen.add(key)
            normalized.append((u, v, w))
        self.edges = normalized
        for city, pos in self.positions.items():
            if city not in self.cities or len(pos) != 2:
                raise ValueError("positions中的城市或坐标不合法。")
            if any(isinstance(x, bool) or not isinstance(x, (int, float))
                   or not math.isfinite(x) for x in pos):
                raise ValueError("节点坐标必须是两个有限数。")
        if not isinstance(self.unit, str) or not self.unit:
            raise ValueError("unit必须是非空字符串。")

    def adjacency(self) -> dict[str, dict[str, float]]:
        adj = {city: {} for city in self.cities}
        for u, v, w in self.edges:
            adj[u][v] = w
            if not self.directed:
                adj[v][u] = w
        return adj

    def to_dict(self) -> dict:
        return {"title": self.title, "directed": self.directed, "unit": self.unit,
                "cities": self.cities, "positions": self.positions,
                "edges": [list(e) for e in self.edges]}

    def changed_edge(self, u: str, v: str, weight: Optional[float]) -> GraphData:
        """返回修改后的新图；weight=None表示删除，原图不变。"""
        if u not in self.cities or v not in self.cities:
            raise ValueError("城市名称不存在，请使用列表中的完整名称。")
        if u == v:
            raise ValueError("不能添加或删除自环。")
        def matches(a, b):
            return (a == u and b == v) or (not self.directed and a == v and b == u)
        exists = any(matches(a, b) for a, b, _ in self.edges)
        if weight is None and not exists:
            raise ValueError(f"{u}—{v}之间没有可删除的连接。")
        edges = [(a, b, w) for a, b, w in self.edges if not matches(a, b)]
        if weight is not None:
            edges.append((u, v, weight))
        return GraphData(self.cities.copy(), edges, self.positions.copy(),
                         self.directed, self.unit, self.title)


def load_graph(path: str | Path) -> GraphData:
    with Path(path).open(encoding="utf-8-sig") as f:
        data = json.load(f)
    return GraphData(cities=data["cities"], edges=data["edges"],
                     positions=data.get("positions", {}),
                     directed=data.get("directed", False),
                     unit=data.get("unit", "时间单位"),
                     title=data.get("title", "城市时间网络"))


def dijkstra(graph: GraphData, source: str):
    """单源最短路。返回距离字典dist与前驱字典prev。

    邻接表+最小堆；复杂度O((V+E)log V)。prev用于从终点反向回溯。
    """
    if source not in graph.cities:
        raise ValueError(f"未知起点：{source}")
    adj = graph.adjacency()
    rank = {city: i for i, city in enumerate(graph.cities)}
    dist = {city: math.inf for city in graph.cities}
    prev = {city: None for city in graph.cities}
    dist[source] = 0.0
    heap = [(0.0, rank[source], source)]
    settled = set()
    while heap:
        current, _, u = heapq.heappop(heap)
        if u in settled or current > dist[u]:
            continue
        settled.add(u)
        for v in sorted(adj[u], key=rank.get):
            if v in settled:
                continue
            candidate = dist[u] + adj[u][v]
            if candidate < dist[v]:
                dist[v] = candidate
                prev[v] = u
                heapq.heappush(heap, (candidate, rank[v], v))
    return dist, prev


def backtrack_path(prev: dict, source: str, target: str) -> list[str]:
    """Dijkstra回溯路由：target -> prev[target] -> ... -> source，再反转。"""
    if source not in prev or target not in prev:
        raise ValueError("查询城市不存在。")
    if source == target:
        return [source]
    if prev[target] is None:
        return []
    reverse = []
    current = target
    for _ in range(len(prev) + 1):
        reverse.append(current)
        if current == source:
            return reverse[::-1]
        current = prev[current]
        if current is None:
            return []
    raise RuntimeError("前驱矩阵出现环路，无法还原路径。")


def all_pairs_dijkstra(graph: GraphData):
    """以每个城市为源点执行Dijkstra，形成距离矩阵和前驱矩阵。"""
    distances, predecessors = [], []
    for source in graph.cities:
        dist, prev = dijkstra(graph, source)
        distances.append([dist[city] for city in graph.cities])
        predecessors.append([prev[city] for city in graph.cities])
    return distances, predecessors


def floyd_warshall(graph: GraphData):
    """Floyd算法，返回距离矩阵dist与前向路由（下一跳）矩阵nxt。

    关键：k必须位于最外层；只有路径严格缩短才更新。
    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])
    nxt[i][j] = nxt[i][k]，而不是简单赋为k。
    时间O(V^3)，空间O(V^2)。
    """
    n = len(graph.cities)
    index = {city: i for i, city in enumerate(graph.cities)}
    dist = [[math.inf] * n for _ in range(n)]
    nxt = [[None] * n for _ in range(n)]
    for i in range(n):
        dist[i][i] = 0.0
        nxt[i][i] = i
    for u, v, weight in graph.edges:
        i, j = index[u], index[v]
        dist[i][j] = weight
        nxt[i][j] = j
        if not graph.directed:
            dist[j][i] = weight
            nxt[j][i] = i
    for k in range(n):
        for i in range(n):
            if math.isinf(dist[i][k]):
                continue
            for j in range(n):
                if math.isinf(dist[k][j]):
                    continue
                candidate = dist[i][k] + dist[k][j]
                if candidate < dist[i][j]:
                    dist[i][j] = candidate
                    nxt[i][j] = nxt[i][k]
    return dist, nxt


def forward_path(nxt: list, cities: list[str], source: str, target: str) -> list[str]:
    """Floyd正向查询：source -> nxt[source][target] -> ... -> target。"""
    if source not in cities or target not in cities:
        raise ValueError("查询城市不存在。")
    i, j = cities.index(source), cities.index(target)
    if nxt[i][j] is None:
        return []
    route = [source]
    for _ in range(len(cities)):
        if i == j:
            return route
        i = nxt[i][j]
        if i is None:
            return []
        route.append(cities[i])
    raise RuntimeError("前向路由矩阵出现环路，无法还原路径。")


def path_cost(graph: GraphData, path: list[str]) -> float:
    if not path:
        return math.inf
    adj = graph.adjacency()
    return sum(adj[u][v] for u, v in zip(path, path[1:]))


def format_number(value: float) -> str:
    if math.isinf(value):
        return "∞"
    return f"{value:.10g}"


class RoutingSolver:
    """两种算法均实际执行；校验距离与每条还原路线的权值。"""
    def __init__(self, graph: GraphData):
        self.graph = graph
        self.dd, self.prev = all_pairs_dijkstra(graph)
        self.df, self.nxt = floyd_warshall(graph)
        self.validate()

    def route(self, source: str, target: str, method: str = "Dijkstra"):
        cities = self.graph.cities
        if source not in cities or target not in cities:
            raise ValueError("查询城市不存在。")
        i, j = cities.index(source), cities.index(target)
        if method == "Dijkstra":
            prev = dict(zip(cities, self.prev[i]))
            return self.dd[i][j], backtrack_path(prev, source, target)
        if method == "Floyd":
            return self.df[i][j], forward_path(self.nxt, cities, source, target)
        raise ValueError("算法名称必须为Dijkstra或Floyd。")

    def validate(self):
        for i, u in enumerate(self.graph.cities):
            for j, v in enumerate(self.graph.cities):
                if not math.isclose(self.dd[i][j], self.df[i][j], rel_tol=1e-10, abs_tol=1e-10):
                    raise AssertionError(f"算法距离不一致：{u}—{v}")
                for method in ("Dijkstra", "Floyd"):
                    distance, path = self.route(u, v, method)
                    if math.isinf(distance):
                        if path:
                            raise AssertionError("不可达城市不应有路由。")
                    elif not math.isclose(distance, path_cost(self.graph, path),
                                          rel_tol=1e-10, abs_tol=1e-10):
                        raise AssertionError(f"路由权值与距离不一致：{u}—{v}")

    def export(self, directory: str | Path) -> list[Path]:
        out = Path(directory)
        out.mkdir(parents=True, exist_ok=True)
        cities = self.graph.cities
        files = []
        def matrix_csv(name, matrix, formatter):
            path = out / name
            with path.open("w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["起点\\终点", *cities])
                for city, row in zip(cities, matrix):
                    writer.writerow([city, *[formatter(x) for x in row]])
            files.append(path)
        matrix_csv("Dijkstra_最短时间矩阵.csv", self.dd, format_number)
        matrix_csv("Floyd_最短时间矩阵.csv", self.df, format_number)
        matrix_csv("Dijkstra_前驱路由矩阵.csv", self.prev, lambda x: x or "—")
        matrix_csv("Floyd_下一跳路由矩阵.csv", self.nxt,
                   lambda x: cities[x] if x is not None else "—")
        path = out / "所有城市对_最短时间与路由.csv"
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["起点", "终点", "最短时间", "时间单位", "Dijkstra路由", "Floyd路由"])
            for u in cities:
                for v in cities:
                    d, p = self.route(u, v, "Dijkstra")
                    _, q = self.route(u, v, "Floyd")
                    writer.writerow([u, v, format_number(d), self.graph.unit,
                                     " → ".join(p) or "不可达", " → ".join(q) or "不可达"])
        files.append(path)
        path = out / "当前网络.json"
        path.write_text(json.dumps(self.graph.to_dict(), ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
        files.append(path)
        return files
